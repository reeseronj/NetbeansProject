package lheen;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class registrationform extends javax.swing.JFrame {

    // 🔹 Constructor
    public registrationform() {
    initComponents();
    loadTableData();

    jTable1.setBackground(java.awt.Color.WHITE);
    jTable1.setForeground(java.awt.Color.BLACK);
    jTable1.setGridColor(java.awt.Color.GRAY);
    jTable1.setSelectionBackground(new java.awt.Color(173, 216, 230));
    jTable1.setSelectionForeground(java.awt.Color.BLACK);
    jScrollPane1.getViewport().setBackground(java.awt.Color.WHITE);
}


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        MALEcheckbox = new javax.swing.JCheckBox();
        FEMALEcheckbox = new javax.swing.JCheckBox();
        jLabel8 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        ADDbutton = new javax.swing.JButton();
        UPDATEbutton = new javax.swing.JButton();
        DELETEbutton = new javax.swing.JButton();
        CLEARbutton = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registration Form");
        setSize(new java.awt.Dimension(1200, 600));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 153), 2));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 153));
        jLabel1.setText("Registration Form");

        jLabel3.setText("First Name:");

        jTextField1.setSelectionColor(new java.awt.Color(255, 255, 255));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel4.setText("Middle Name:");

        jLabel5.setText("Last Name:");

        jLabel6.setText("Address:");

        jLabel7.setText("Sex:");

        MALEcheckbox.setText("MALE");
        MALEcheckbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MALEcheckboxActionPerformed(evt);
            }
        });

        FEMALEcheckbox.setText("FEMALE");
        FEMALEcheckbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FEMALEcheckboxActionPerformed(evt);
            }
        });

        jLabel8.setText("Religion:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Religion", "Roman Catholic", "Islam", "Iglesia ni Cristo", "Aglipayan Church", "Protestantism", "Buddhism", "Hinduism", "Judaism", "Atheism", " " }));

        ADDbutton.setBackground(new java.awt.Color(255, 153, 153));
        ADDbutton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        ADDbutton.setForeground(new java.awt.Color(255, 255, 255));
        ADDbutton.setText("Add");
        ADDbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDbuttonActionPerformed(evt);
            }
        });

        UPDATEbutton.setBackground(new java.awt.Color(255, 153, 153));
        UPDATEbutton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        UPDATEbutton.setForeground(new java.awt.Color(255, 255, 255));
        UPDATEbutton.setText("Update");
        UPDATEbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPDATEbuttonActionPerformed(evt);
            }
        });

        DELETEbutton.setBackground(new java.awt.Color(255, 153, 153));
        DELETEbutton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        DELETEbutton.setForeground(new java.awt.Color(255, 255, 255));
        DELETEbutton.setText("Delete");
        DELETEbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DELETEbuttonActionPerformed(evt);
            }
        });

        CLEARbutton.setBackground(new java.awt.Color(255, 153, 153));
        CLEARbutton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        CLEARbutton.setForeground(new java.awt.Color(255, 255, 255));
        CLEARbutton.setText("Clear");
        CLEARbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CLEARbuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(MALEcheckbox)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(FEMALEcheckbox))
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField1)
                            .addComponent(jTextField2)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(ADDbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DELETEbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(CLEARbutton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(UPDATEbutton, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE))))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MALEcheckbox)
                    .addComponent(FEMALEcheckbox))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ADDbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UPDATEbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DELETEbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CLEARbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 153), 2));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, "", "", "", "", "", null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "First Name", "Middle Name", "Last Name", "Address", "Sex", "Religion"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setGridColor(new java.awt.Color(255, 255, 255));
        jTable1.setMaximumSize(new java.awt.Dimension(32767, 32767));
        jTable1.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jTable1.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 153));
        jLabel2.setText("Registered List");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 765, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(0, 636, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void MALEcheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MALEcheckboxActionPerformed
                                                 
    if (MALEcheckbox.isSelected()) {
        FEMALEcheckbox.setSelected(false);
    }



        // TODO add your handling code here:
    }//GEN-LAST:event_MALEcheckboxActionPerformed

    private void ADDbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDbuttonActionPerformed
    String firstName = jTextField1.getText().trim();
        String middleName = jTextField2.getText().trim();
        String lastName = jTextField3.getText().trim();
        String address = jTextField4.getText().trim();
        String sex = MALEcheckbox.isSelected() ? "MALE" : (FEMALEcheckbox.isSelected() ? "FEMALE" : "");
        String religion = (String) jComboBox1.getSelectedItem();

        if (firstName.isEmpty() || lastName.isEmpty() || address.isEmpty() ||
            sex.isEmpty() || religion == null || religion.equals("Select Religion")) {
            JOptionPane.showMessageDialog(this, "Please fill out all fields properly.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement ps = conn.prepareStatement(
                 "INSERT INTO registrants (first_name, middle_name, last_name, address, sex, religion) VALUES (?, ?, ?, ?, ?, ?)")) {

            ps.setString(1, firstName);
            ps.setString(2, middleName);
            ps.setString(3, lastName);
            ps.setString(4, address);
            ps.setString(5, sex);
            ps.setString(6, religion);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Record added successfully!");
            loadTableData();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }



    }//GEN-LAST:event_ADDbuttonActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void UPDATEbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPDATEbuttonActionPerformed
                                                 
    if (selectedID == -1) {
        JOptionPane.showMessageDialog(this, "Please select a record to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
        return;
    }

    String firstName = jTextField1.getText().trim();
    String middleName = jTextField2.getText().trim();
    String lastName = jTextField3.getText().trim();
    String address = jTextField4.getText().trim();
    String sex = MALEcheckbox.isSelected() ? "MALE" : (FEMALEcheckbox.isSelected() ? "FEMALE" : "");
    String religion = (String) jComboBox1.getSelectedItem();

    if (firstName.isEmpty() || lastName.isEmpty() || address.isEmpty() ||
        sex.isEmpty() || religion == null || religion.equals("Select Religion")) {
        JOptionPane.showMessageDialog(this, "Please fill out all fields properly.", "Input Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement ps = conn.prepareStatement(
             "UPDATE registrants SET first_name=?, middle_name=?, last_name=?, address=?, sex=?, religion=? WHERE id=?")) {

        ps.setString(1, firstName);
        ps.setString(2, middleName);
        ps.setString(3, lastName);
        ps.setString(4, address);
        ps.setString(5, sex);
        ps.setString(6, religion);
        ps.setInt(7, selectedID);

        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, "Record updated successfully!");
        loadTableData();

        // Reset selection
        selectedID = -1;

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }









    }//GEN-LAST:event_UPDATEbuttonActionPerformed

    private void DELETEbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETEbuttonActionPerformed
                                                 
    if (selectedID == -1) {
        JOptionPane.showMessageDialog(this, "Please select a record to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "Delete this record?", "Confirm", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM registrants WHERE id=?")) {
            ps.setInt(1, selectedID);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record deleted successfully!");
            loadTableData();
            selectedID = -1;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }












    }//GEN-LAST:event_DELETEbuttonActionPerformed

    private void CLEARbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CLEARbuttonActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        MALEcheckbox.setSelected(false);
        FEMALEcheckbox.setSelected(false);
        jComboBox1.setSelectedIndex(0);
    
    }//GEN-LAST:event_CLEARbuttonActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
                                         
                                       
    int selectedRow = jTable1.getSelectedRow();
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

    if (selectedRow >= 0) {
        // Store the hidden ID in a variable (not shown in textfield)
        selectedID = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());

        // Fill the form fields
        jTextField1.setText(model.getValueAt(selectedRow, 1).toString()); // First Name
        jTextField2.setText(model.getValueAt(selectedRow, 2).toString()); // Middle Name
        jTextField3.setText(model.getValueAt(selectedRow, 3).toString()); // Last Name
        jTextField4.setText(model.getValueAt(selectedRow, 4).toString()); // Address

        // Handle checkboxes
        String sex = model.getValueAt(selectedRow, 5).toString();
        MALEcheckbox.setSelected(sex.equalsIgnoreCase("MALE"));
        FEMALEcheckbox.setSelected(sex.equalsIgnoreCase("FEMALE"));

        // Handle religion
        jComboBox1.setSelectedItem(model.getValueAt(selectedRow, 6).toString());
    }













    }//GEN-LAST:event_jTable1MouseClicked

    private void FEMALEcheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FEMALEcheckboxActionPerformed
        if (FEMALEcheckbox.isSelected()) {
        MALEcheckbox.setSelected(false);
    }




    }//GEN-LAST:event_FEMALEcheckboxActionPerformed


    private void loadTableData() {
    try (Connection conn = DatabaseConnection.connect();
         Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery("SELECT * FROM registrants")) {

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        // Load records including ID (hidden)
        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),               // Hidden ID
                rs.getString("first_name"),    // Visible column 1
                rs.getString("middle_name"),   // Visible column 2
                rs.getString("last_name"),     // Visible column 3
                rs.getString("address"),       // Visible column 4
                rs.getString("sex"),           // Visible column 5
                rs.getString("religion")       // Visible column 6
            });
        }

        // Hide ID column
        jTable1.getColumnModel().getColumn(0).setMinWidth(0);
        jTable1.getColumnModel().getColumn(0).setMaxWidth(0);
        jTable1.getColumnModel().getColumn(0).setWidth(0);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        e.printStackTrace();
    }
}



    // 🔹 Main method
    
    public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(() -> new registrationform().setVisible(true));
}




    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADDbutton;
    private javax.swing.JButton CLEARbutton;
    private javax.swing.JButton DELETEbutton;
    private javax.swing.JCheckBox FEMALEcheckbox;
    private javax.swing.JCheckBox MALEcheckbox;
    private javax.swing.JButton UPDATEbutton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
private int selectedID = -1;
}
