package com.mycompany.rehistrasyun;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.Vector;

public class RegistrationForm extends JFrame {
    // Form components
    private JTextField txtFirstName, txtMiddleName, txtLastName, txtAddress;
    private JCheckBox chkMale, chkFemale;
    private JComboBox<String> cmbReligion;
    private JButton btnAdd, btnUpdate, btnDelete, btnClear;
    private JTable table;
    private DefaultTableModel tableModel;
    
    public RegistrationForm() {
        initComponents();
        setTitle("Registration System");
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);
    }
    
    private void initComponents() {
        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // LEFT SIDE - Registration Form
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.PINK, 2),
            "Registration Form",
            0, 0, new Font("Arial", Font.BOLD, 16),
            Color.PINK
        ));

        formPanel.setPreferredSize(new Dimension(400, 0));
        formPanel.setBackground(Color.WHITE);

        // First Name
        formPanel.add(createPinkLabel("First Name:"));
        txtFirstName = new JTextField();
        txtFirstName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        txtFirstName.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(txtFirstName);
        formPanel.add(Box.createVerticalStrut(10));

        // Middle Name
        formPanel.add(createPinkLabel("Middle Name:"));
        txtMiddleName = new JTextField();
        txtMiddleName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        txtMiddleName.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(txtMiddleName);
        formPanel.add(Box.createVerticalStrut(10));

        // Last Name
        formPanel.add(createPinkLabel("Last Name:"));
        txtLastName = new JTextField();
        txtLastName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        txtLastName.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(txtLastName);
        formPanel.add(Box.createVerticalStrut(10));

        // Address
        formPanel.add(createPinkLabel("Address:"));
        txtAddress = new JTextField();
        txtAddress.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        txtAddress.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(txtAddress);
        formPanel.add(Box.createVerticalStrut(10));

        // Sex (Checkboxes)
        formPanel.add(createPinkLabel("Sex:"));
        JPanel sexPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sexPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        sexPanel.setBackground(Color.WHITE);
        sexPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        chkMale = new JCheckBox("Male");
        chkFemale = new JCheckBox("Female");

        // Make checkboxes pink
        chkMale.setForeground(Color.PINK);
        chkFemale.setForeground(Color.PINK);

        // Ensure only one checkbox can be selected
        chkMale.addActionListener(e -> {
            if (chkMale.isSelected()) chkFemale.setSelected(false);
        });
        chkFemale.addActionListener(e -> {
            if (chkFemale.isSelected()) chkMale.setSelected(false);
        });

        sexPanel.add(chkMale);
        sexPanel.add(chkFemale);
        formPanel.add(sexPanel);
        formPanel.add(Box.createVerticalStrut(10));

        // Religion
        formPanel.add(createPinkLabel("Religion:"));
        String[] religions = {"Select Religion", "Christianity", "Islam", "Buddhism", 
                             "Hinduism", "Judaism", "Other", "Prefer not to say"};
        cmbReligion = new JComboBox<>(religions);
        cmbReligion.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        cmbReligion.setAlignmentX(Component.LEFT_ALIGNMENT);
        cmbReligion.setForeground(Color.PINK); // make "Select Religion" pink
        formPanel.add(cmbReligion);
        formPanel.add(Box.createVerticalStrut(20));

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnClear = new JButton("Clear");

        // make buttons permanently pink
        Color pinkColor = Color.PINK;
        Color whiteColor = Color.WHITE;
        for (JButton btn : new JButton[]{btnAdd, btnUpdate, btnDelete, btnClear}) {
            btn.setBackground(pinkColor);
            btn.setForeground(whiteColor);
            btn.setFocusPainted(false);
            btn.setOpaque(true); // ensures button color is fixed visible
            btn.setBorderPainted(false); // removes default border highlight
            btn.setFont(new Font("Arial", Font.BOLD, 13));
        }

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnClear);

        formPanel.add(buttonPanel);
        formPanel.add(Box.createVerticalGlue());

        // RIGHT SIDE - Table
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.PINK, 2),
            "Registered List",
            0, 0, new Font("Arial", Font.BOLD, 16),
            Color.PINK
        ));

        // Create table
        String[] columnNames = {"ID", "First Name", "Middle Name", "Last Name", 
                               "Address", "Sex", "Religion"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel) {
            @Override
            protected JTableHeader createDefaultTableHeader() {
                return new JTableHeader(columnModel) {
                    @Override
                    public String getToolTipText(java.awt.event.MouseEvent e) {
                        return null; 
                    }
                };
            }
        };

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setReorderingAllowed(false);
        table.setRowHeight(25);

        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer((tbl, value, isSelected, hasFocus, row, col) -> {
            JLabel lbl = new JLabel(value.toString());
            lbl.setOpaque(true);
            lbl.setBackground(Color.PINK);    
            lbl.setForeground(Color.WHITE);   
            lbl.setFont(new Font("Arial", Font.BOLD, 12));
            lbl.setHorizontalAlignment(SwingConstants.CENTER);
            return lbl;
        });

        JScrollPane scrollPane = new JScrollPane(table);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(formPanel, BorderLayout.WEST);
        mainPanel.add(tablePanel, BorderLayout.CENTER);

        add(mainPanel);

        addEventHandlers();

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                loadSelectedRow();
            }
        });
    }
    
    private JLabel createPinkLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 13));
        label.setForeground(Color.PINK); // pink label text
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }
    
    private void addEventHandlers() {
        btnAdd.addActionListener(e -> addRecord());
        btnUpdate.addActionListener(e -> updateRecord());
        btnDelete.addActionListener(e -> deleteRecord());
        btnClear.addActionListener(e -> clearFields());
    }
    
    private void addRecord() {
        if (validateFields()) {
            String sex = chkMale.isSelected() ? "Male" : "Female";
            int id = tableModel.getRowCount() + 1;
            
            Vector<Object> row = new Vector<>();
            row.add(id);
            row.add(txtFirstName.getText().trim());
            row.add(txtMiddleName.getText().trim());
            row.add(txtLastName.getText().trim());
            row.add(txtAddress.getText().trim());
            row.add(sex);
            row.add(cmbReligion.getSelectedItem().toString());
            
            tableModel.addRow(row);
            clearFields();
            JOptionPane.showMessageDialog(this, "Record added successfully!", 
                                        "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void updateRecord() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a record to update!", 
                                        "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (validateFields()) {
            String sex = chkMale.isSelected() ? "Male" : "Female";
            
            tableModel.setValueAt(txtFirstName.getText().trim(), selectedRow, 1);
            tableModel.setValueAt(txtMiddleName.getText().trim(), selectedRow, 2);
            tableModel.setValueAt(txtLastName.getText().trim(), selectedRow, 3);
            tableModel.setValueAt(txtAddress.getText().trim(), selectedRow, 4);
            tableModel.setValueAt(sex, selectedRow, 5);
            tableModel.setValueAt(cmbReligion.getSelectedItem().toString(), selectedRow, 6);
            
            clearFields();
            table.clearSelection();
            JOptionPane.showMessageDialog(this, "Record updated successfully!", 
                                        "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void deleteRecord() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a record to delete!", 
                                        "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this record?", 
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            tableModel.removeRow(selectedRow);
            updateIDs();
            clearFields();
            JOptionPane.showMessageDialog(this, "Record deleted successfully!", 
                                        "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void updateIDs() {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt(i + 1, i, 0);
        }
    }
    
    private void loadSelectedRow() {
        int selectedRow = table.getSelectedRow();
        txtFirstName.setText(tableModel.getValueAt(selectedRow, 1).toString());
        txtMiddleName.setText(tableModel.getValueAt(selectedRow, 2).toString());
        txtLastName.setText(tableModel.getValueAt(selectedRow, 3).toString());
        txtAddress.setText(tableModel.getValueAt(selectedRow, 4).toString());
        
        String sex = tableModel.getValueAt(selectedRow, 5).toString();
        chkMale.setSelected(sex.equals("Male"));
        chkFemale.setSelected(sex.equals("Female"));
        
        cmbReligion.setSelectedItem(tableModel.getValueAt(selectedRow, 6).toString());
    }
    
    private void clearFields() {
        txtFirstName.setText("");
        txtMiddleName.setText("");
        txtLastName.setText("");
        txtAddress.setText("");
        chkMale.setSelected(false);
        chkFemale.setSelected(false);
        cmbReligion.setSelectedIndex(0);
        table.clearSelection();
    }
    
    private boolean validateFields() {
        if (txtFirstName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter First Name!", 
                                        "Validation Error", JOptionPane.ERROR_MESSAGE);
            txtFirstName.requestFocus();
            return false;
        }
        
        if (txtLastName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Last Name!", 
                                        "Validation Error", JOptionPane.ERROR_MESSAGE);
            txtLastName.requestFocus();
            return false;
        }
        
        if (txtAddress.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Address!", 
                                        "Validation Error", JOptionPane.ERROR_MESSAGE);
            txtAddress.requestFocus();
            return false;
        }
        
        if (!chkMale.isSelected() && !chkFemale.isSelected()) {
            JOptionPane.showMessageDialog(this, "Please select Sex!", 
                                        "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (cmbReligion.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Please select Religion!", 
                                        "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            new RegistrationForm().setVisible(true);
        });
    }
}
    